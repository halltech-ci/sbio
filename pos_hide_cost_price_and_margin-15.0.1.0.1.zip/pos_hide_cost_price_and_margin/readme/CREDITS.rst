The development of this module for 15.0 was financially supported by Camptocamp
