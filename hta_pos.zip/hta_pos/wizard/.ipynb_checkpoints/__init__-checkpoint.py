# -*- coding: utf-8 -*-

from . import assign_commands_wizard
from . import payment_after_delivery
from . import wizard_report_pos