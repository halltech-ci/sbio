#. Go to Website Shop.
#. Activate filter by attributes in "Customize" option in top menu.
#. Activate attributes categories filters in "Customize" option in top menu.
#. Now you can see product attributes filter grouped by categories.
