This module extends the functionality of website sale module to allow to group
product attributes filter by their categories.
Also you can select if you want display folded or unfolded category in website
attribute's filter.
