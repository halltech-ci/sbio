To configure this module, you need to:

* Go to 'Website > Configuration > Attribute Categories' and create one.
  You can select if you want display it folded or unfolded in website.
* Go to 'Website > Configuration > Attributes, create one or more with
  this category and add more than one value for each attribute.
* Go to 'Website > Products > Products' and create a product with this
  attribute and assign it an attribute value.
