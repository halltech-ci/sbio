* Take into account workstations.
* Take into account consumable products.
