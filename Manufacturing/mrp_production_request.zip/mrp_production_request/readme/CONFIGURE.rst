To configure a product to automatically generate Manufacturing Requests
from procurements instead of directly create manufacturing orders you
need to:

#. Go to the products that you want them to trigger manufacturing requests.
#. Go to the *Inventory* tab.
#. Check the box of a *manufacture* route and the box of
   *Manufacturing Request*.
