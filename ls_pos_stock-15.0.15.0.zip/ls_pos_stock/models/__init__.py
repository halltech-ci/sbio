from . import res_config_settings
from . import pos_config