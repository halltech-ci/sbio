
=> 15.0.0.1 : Add French, Spanish , Arabic and Dutch translation in module also improved an index.

Version 15.0.0.2 : (02-03-22)
		- Update code for receipt print.