## Module <animated_snippet>

#### 12.06.2023
#### Version 16.0.1.0.0
#### ADD

- Initial Commit for Animated Snippets